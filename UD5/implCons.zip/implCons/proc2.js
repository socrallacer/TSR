/*************************************************************************/
/*                                                                       */
/* proc2.js                                                              */
/*                                                                       */
/* This program emulates a process in a distributed system with a set    */
/* of shared variables.                                                  */
/*                                                                       */
/* The process identifier should be passed as an argument from the       */
/* command line.                                                         */
/*                                                                       */
/*************************************************************************/

sh = require("./shared2");
var myID; // Process identifier.
var multipliers = [11,13,17,19,23,29,31,37,41,43,47,53,59];

/*************************************************************************/
/* getID()                                                               */
/* Returns the first argument given in the command line.                 */
/* Prints an error message and aborts the program if none is given.      */
/*                                                                       */
/*************************************************************************/
function getID() {
    // Get the command-line arguments.
    args = process.argv;
    // Check whether at least an argument has been given.
    if (args.length < 3) {
	// If not, print an error message and exit.
	console.log("ERROR: Please enter the process identifier as the " + 
		    "first argument in the command line!");
	process.exit();
    }
    // Otherwise, return it as the process ID.
    return parseInt(args[2]);
}

/*************************************************************************/
/* writeValue()                                                          */
/* Write a value derived from the process identifier onto "x" (the       */
/* shared variable).                                                     */
/*************************************************************************/
var counter=0;
function writeValue() {
    // Write the process ID onto variable "x".
    sh.W("x",myID*multipliers[counter++ % multipliers.length]);
}

/*************************************************************************/
/* myActivity()                                                          */
/* We use a first pause of in order to wait for connection management.   */
/*************************************************************************/
function myActivity() {
    setInterval(writeValue, 10);
}

// Obtains the process ID.
myID = getID();
// Initialises the shared2 module.
sh.init(myID);
sh.W("y", myID); // Unimportant write.
// Let the process start in two seconds.
setTimeout(myActivity,2000);
// Terminate the process after some time.
setTimeout(process.exit,3000);

