/*************************************************************************/
/* shared2.js                                                            */
/* Module that supports a non-strict consistency model.                  */
/*************************************************************************/    

// 0MQ is used as the communication module.
var zmq = require('zeromq');

// Two interaction patterns are used. In the first step, each process uses
// a push/pull channel to forward its message to the sequencer. Later,
// the sequencer used a pub/sub channel to broadcast the message to all
// other processes.
// As a result, every regular process (i.e., non-sequencer) uses a push
// and a sub socket.
var ps = zmq.socket('push');
var sb = zmq.socket('sub');
// The "local" object emulates the shared memory. Each one of its 
// attributes is a shared variable.
var local = {};
// Ports being used by the sequencer process.
var seqPubPort = "9999";
var seqPullPort = "9998";
var url = "tcp://127.0.0.1:";
// Boolean variable that is set to true while a value is written and
// propagated to the remaining nodes.
var writing = false;


/*=======================================================================*/
/* PRIVATE FUNCTIONS                                                     */
/*=======================================================================*/    

/*************************************************************************/
/* join()                                                                */
/* The local process uses this function to connect its "subscriber"      */
/* socket to the "publisher" socket of the sequencer process and its     */
/* "push" to the "pull" socket to the sequencer.                         */
/*************************************************************************/
function join() {
    // Connect the push socket to the pull socket of the sequencer.
    ps.connect(url+seqPullPort);
    // Subscribe to everything.
    sb.subscribe("");
    // Connect the sub socket to the pub socket of the sequencer.
    sb.connect(url+seqPubPort);
}

// The local process ID is initially set to -1.
var id = -1;

/*************************************************************************/
/* myID(nid)                                                             */
/* Sets the local process ID and binds its publisher socket to its       */
/* intended port.                                                        */
/* Input args:                                                           */
/* - nid: Process identifier in the range 0..9                           */
/*************************************************************************/     
function myID(nid) {
    // Checks whether the function has already been called.
    if (id!=-1)
	// If so, return without doing anything else.
	return;
    // Save the process identifier. "id" is global variable.
    id = parseInt(nid);
    // If the identifier has a wrong value, print an error message and
    // abort.
    if (isNaN(id) || id < 0 || id > 9) {
	console.log("ERROR: The node identifier should be a number " +
		    "in the range 0..9!!");
	process.exit();
    }
}

/*=======================================================================*/
/* PUBLIC FUNCTIONS                                                      */
/*=======================================================================*/

/*************************************************************************/
/* init(nodes)                                                           */
/* Initialises the "shared2" module, receiving the identifier of the     */
/* invoker local process.                                                */
/* Input args:                                                           */
/* - id: Local process identifier.                                       */
/*************************************************************************/
exports.init = function(id) {
    join();
    myID(id);
}

/*************************************************************************/
/* W(name,value)                                                         */
/* Writes the "value" value onto the "name" shared variable.             */
/* Input args:                                                           */
/* - name: String with the name of the shared variable being written.    */
/* - value: Value to be written.                                         */
/*************************************************************************/
exports.W = function (name, value) {
    // Propagate the <name,value> pair to the sequencer.
    ps.send([name, value, id]);
};

/*************************************************************************/
/* R(name)                                                               */
/* Reads the current value of the "name" shared variable.                */
/* Input args:                                                           */
/* - name: String with the name of the shared variable being read.       */
/* Return value:                                                         */
/* - Current value of such variable.                                     */
/*************************************************************************/
exports.R = function (name) {
    // Write a message on standard output describing this read action.
    process.stdout.write("R" + id + "(" + name + ")" + local[name] + ":");
    // Return the read value.
    return local[name];
};

/*************************************************************************/
/* 'message' event handler                                               */
/* The messages being broadcast through the pub/sub channel consist in   */
/* an array with 3 slots: "name", "value" and "writer".                  */
/* We store the received value onto the local copy of the "name"         */
/* variable.                                                             */
/* In order to follow the trace, a "read" event is printed on screen.    */
/*************************************************************************/
sb.on('message', function (name, value, writer) {
    if (writer==id) {
	// Print a message on screen about its previous write action.
	process.stdout.write("W" + id + "(" + name + ")" + value + ":");
    }
    // Set the received value onto the local copy of the variable.
    local[name] = value;
    // Print a message on screen, emulating a local read.
    if (writer!=id) exports.R(name);
});

