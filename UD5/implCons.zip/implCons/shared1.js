/*************************************************************************/
/* shared1.js                                                            */
/* Module that supports a non-strict consistency model.                  */
/*************************************************************************/     

// 0MQ is used as the communication module.
var zmq = require('zeromq');

// The publish/subscribe interaction pattern is used. A socket of each
// kind is needed.
var pb = zmq.socket('pub');
var sb = zmq.socket('sub');
// Global subscription.
sb.subscribe("");
// The "local" object emulates the shared memory. Each one of its 
// attributes is a shared variable.
var local = {};
// In order to be easy to use, this module assumes that all processes
// are deployed onto the same computer. So, each one uses a different
// port. To this end, a common prefix is used. Each process uses its
// identifier as a suffix of such port number.
var prefixPort = "1000";

/*=======================================================================*/
/* PRIVATE FUNCTIONS                                                     */
/*=======================================================================*/    

/*************************************************************************/
/* join(nodes)                                                           */
/* The local process uses this function to connect its "subscriber"      */
/* socket to the "publisher" sockets of the remaining processes.         */
/* Input args:                                                           */
/* - nodes: An array with the endpoints of all system processes.         */
/*************************************************************************/
function join(nodes) {
    // Iterate onto the "nodes" array, connecting the local subscriber
    // socket to the endpoint held in each array slot.
    nodes.forEach(function (ep) {
	sb.connect(ep);
    });
}

// The local process ID is initially set to -1.
var id = -1;

/*************************************************************************/
/* myID(nid)                                                             */
/* Sets the local process ID and binds its publisher socket to its       */
/* intended port.                                                        */
/* Input args:                                                           */
/* - nid: Process identifier in the range 0..9                           */
/*************************************************************************/     
function myID(nid) {
    // Checks whether the function has already been called.
    if (id!=-1)
	// If so, return without doing anything else.
	return;
    // Save the process identifier. "id" is a global variable.
    id = parseInt(nid);
    // If the identifier has a wrong value, print an error message and
    // abort.
    if (isNaN(id) || id < 1 || id > 9) {
	console.log("ERROR: The node identifier should be a number " +
		    "in the range 1..9!!");
	process.exit();
    }
    // Bind the publisher socket to the appropriate port.
    pb.bindSync("tcp://127.0.0.1:"+prefixPort+id);
}

/*=======================================================================*/
/* PUBLIC FUNCTIONS                                                      */
/*=======================================================================*/

/*************************************************************************/
/* init(id)                                                              */
/* Initialises the "shared1" module, receiving the identifier of the     */
/* invoker local process.                                                */
/* Input args:                                                           */
/* - id: Local process identifier.                                       */
/*************************************************************************/
exports.init = function(id) {
    var i;
    var nodes=[];
    for (i=0; i<10; i++)
	nodes.push("tcp://127.0.0.1:"+prefixPort+i);
    join(nodes);
    myID(id);
}

// Prefix of the port number to be used.
exports.prefixPort = prefixPort;

/*************************************************************************/
/* W(name,value)                                                         */
/* Writes the "value" value onto the "name" shared variable.             */
/* Input args:                                                           */
/* - name: String with the name of the shared variable being written.    */
/* - value: Value to be written.                                         */
/*************************************************************************/
exports.W = function (name, value) {
    // Write a message on standard output describing this write action.
    // We do not use console.log() since it always writes a final newline
    // character.
    process.stdout.write("W" + id + "(" + name + ")" + value + ":" );
    // Propagate <name,value,pid> to all system processes.
    pb.send([name, value, id]);
    // Write also such value onto the local copy of the "name" variable.
    local[name] = value;
};

/*************************************************************************/
/* R(name)                                                               */
/* Reads the current value of the "name" shared variable.                */
/* Input args:                                                           */
/* - name: String with the name of the shared variable being read.       */
/* Return value:                                                         */
/* - Current value of such variable.                                     */
/*************************************************************************/
exports.R = function (name) {
    // Write a message on standard output describing this read action.
    process.stdout.write("R" + id + "(" + name + ")" + local[name] + ":");
    // Return the read value.
    return local[name];
};

/*************************************************************************/
/* 'message' event handler                                               */
/* The messages being broadcast through the pub/sub channel consist of   */
/* three segments: "name", "value" and "sender".                         */
/* We store the received value onto the local copy of the "name"         */
/* variable.                                                             */
/* In order to follow the trace, a "read" event is printed on screen.    */
/*************************************************************************/
sb.on('message', function (name, value, sender) {
    if (sender != id) {
        // Set the received value onto the local copy of the variable.
        local[name] = value;
        // Print a message on screen, emulating a local read.
        exports.R(name);
    }
});

