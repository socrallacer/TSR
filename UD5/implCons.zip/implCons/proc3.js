/*************************************************************************/
/*                                                                       */
/* proc3.js                                                              */
/*                                                                       */
/* This program emulates a process in a distributed system with a set    */
/* of shared variables.                                                  */
/*                                                                       */
/* The process identifier should be passed as an argument from the       */
/* command line.                                                         */
/*                                                                       */
/*************************************************************************/

sh = require("./shared3");
var myID; // Process identifier.
var multipliers = [11,13,17,19,23,29,31,37,41,43,47,53,59];

/*************************************************************************/
/* getID()                                                               */
/* Returns the first argument given in the command line.                 */
/* Prints an error message and aborts the program if none is given.      */
/*                                                                       */
/*************************************************************************/
function getID() {
    // Get the command-line arguments.
    args = process.argv;
    // Check whether at least an argument has been given.
    if (args.length < 3) {
	// If not, print an error message and exit.
	console.log("ERROR: Please enter the process identifier as the " + 
		    "first argument in the command line!");
	process.exit();
    }
    // Otherwise, return it as the process ID.
    return parseInt(args[2]);
}

/*************************************************************************/
/* writeValue()                                                          */
/* Write a value derived from the process identifier onto "x" (the       */
/* shared variable).                                                     */
/*************************************************************************/
var counter=0;
function writeValue() {
    // Write the process ID onto variable "x".
    sh.W("x",myID*multipliers[counter++ % multipliers.length]);
}

var inter=0;
/*************************************************************************/
/* terminate()                                                           */
/* Terminates the process, writing to screen the final value of the      */
/* shared variable.                                                      */
/*************************************************************************/
function terminate() {
    function a() {
	console.log("P%d final value: %d", myID, sh.R("x"));
	process.exit();
    }
    clearInterval(inter);
    setTimeout(a,100);
}

function myActivity() {
    inter=setInterval(writeValue,10);
}

// Obtains the process ID.
myID = getID();
// Initialises the shared3 module.
sh.init(myID);
// Unimportante initial write.
sh.W("y", myID);
// Let the process start in two seconds.
setTimeout(myActivity, 2000);
// Terminate the process after some time.
setTimeout(terminate,3000);

