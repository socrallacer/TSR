// Modules to be imported.
const cluster = require('cluster')
const net = require('net')
const math = require('./auxMath.js')
const numCPUs = require('os').cpus().length
const seconds = 30  // Length of the elasticity management interval.
let numWorkers = 0

// SIGTERM and SIGKILL handler.
function terminate() {
    // Kill all the worker processes.
    for (let i in cluster.workers) {
        console.log("Sending signal SIGTERM to worker %d.", cluster.workers[i].process.pid)
        cluster.workers[i].kill('SIGTERM')
        numWorkers--
    }
    // Terminate the master.
    process.exit(1)
}


// Show the statistics every 5 seconds.
function show() {
    for(let i in cluster.workers) {
        console.log("Worker %d with PID %d has processed...", i, cluster.workers[i].process.pid)
        console.log("   %d requests in the last interval", cluster.workers[i].reqsLastInterval)
        console.log("   %d requests since it started", cluster.workers[i].reqs)
    }
    // Write an empty line in order to easily identify each report.
    console.log("")
}

// Get the port number from the command-line arguments. Default values are given.
const port = parseInt(process.argv[2]) || 8000
const minrate = parseInt(process.argv[3]) || 500
const maxrate = parseInt(process.argv[4]) || 2000
// Check whether the service rates are correct.
if (minrate > maxrate) {
    console.error("Error: The minimum service rate should be lower than the maximum service rate!")
    process.exit(1)
}

// Update the request counters each time a worker message is received.
// Use a closure to remember the worker ID.
function handleWorkerMessage(id) {
    return (msg) => {
        // Handle worker message.
        cluster.workers[id].reqs++
        cluster.workers[id].reqsLastInterval++
    }
}

// Manage elasticity decisions every 30 seconds.
function elasticityMgmnt() {
    let decided = false
    for (let i in cluster.workers) {
        if (!decided) {
            decided = true
            // Check how many requests have been processed by the first
            // worker and react accordingly.
            requests = cluster.workers[i].reqsLastInterval
            // Reset the counter of requests served in the last interval.
            // Since scale-in actions may be taken hereafter, this reset
            // action should be done here, before killing the corresponding
            // worker.
            cluster.workers[i].reqsLastInterval=0
            // Compute current service rate.
            let rate = requests / seconds
            // Show that rate.
            console.log("Current service rate per worker: %d req/sec", rate)
            console.log("Number of workers: %d", numWorkers)
            // Should we scale in?
            if (rate < minrate && numWorkers > numCPUs) {
                cluster.workers[i].kill()
                console.log("Scaling in...")
                numWorkers--
            } else 
            // Should we scale out?
            if (rate > maxrate && numWorkers < 2*numCPUs) {
                let workObj = cluster.fork()
                workObj.reqs=0
                workObj.reqsLastInterval=0
                workObj.on('message', handleWorkerMessage(workObj.id))
                console.log("Scaling out...")
                numWorkers++
            } else
            console.log("No scaling action is needed now!")
        }
        // Reset the amount of requests managed in the last interval at each worker.
        else cluster.workers[i].reqsLastInterval=0
    }
}

// Main program.
if (cluster.isMaster) {
    // Show the current configuration, received from the command line arguments or
    // from the default values.
    console.log("Current configuration:")
    console.log(" - port number:            %d", port)
    console.log(" - scale-in service rate:  %d req/sec", minrate)
    console.log(" - scale-out service rate: %d req/sec", maxrate)
    // Manage master termination.
    process.on('SIGTERM', terminate )
    process.on('SIGINT', terminate )
    // Create as many workers as processors.
    for(let i=0; i<numCPUs; i++) cluster.fork()
    numWorkers = numCPUs
    // Manage worker messages.
    for(let i in cluster.workers) {
        cluster.workers[i].on('message', handleWorkerMessage(i))
        // Initialise worker counters.
        cluster.workers[i].reqs=0
        cluster.workers[i].reqsLastInterval=0
    }
    // Program the periodical actions.
    setInterval(show, 5000)
    setInterval(elasticityMgmnt, seconds*1000)
}
else
// Main function of worker processes.
{
    console.log( "Starting worker with PID %d.",process.pid)
    // Create a net math server.
    const server = net.createServer(
        function (c) {
            c.on('data', function (data) {
                var obj = JSON.parse(data)
                var res = math.calculate(obj)
                c.write(obj.func + '(' + obj.numb + ') = ' + res)
                process.send("req")
            })
            c.on('end', function() {c.end()})
        })
    // Listen to the given port.
    server.listen(port)
}
