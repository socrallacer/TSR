// net_client.js

var net = require('net');
if (process.argv.length != 3) {
    console.log('usage: node net_client port');
    process.exit(0);
}
function random_request() {
    var func = (Math.random() < 0.5) ? 'fibo' : 'fact';
    var max = (func == 'fibo') ? 36 : 100;
    var numb = Math.round(Math.random() * max);
    return JSON.stringify({ "func": func, "numb": numb });
}
function net_client() {
    var cont = 0;
    var client = net.connect(
        { port: process.argv[2] },
        function () { //'connect' listener
            client.write(random_request());
        });
    client.on('data', function (data) {
// The following reporting message shouldn't be shown...
// since otherwise, the client process would not be able
// to send its messages at the intended rate.
//       console.log(data.toString());
        cont++;
        if (cont < 10)
            client.write(random_request());
        else {
            client.end();
        }
    });
    client.on('error', function (err) {
        client.end();
    });
}

let handle = setInterval(net_client, 10);

// When a termination signal is received, the periodical
// message sending is cancelled. The process should not be
// terminated immediately, since there may be some in-transit
// responses. If the process ends while those messages
// are propagated, the connection breaks and the server will
// die.
function handleSignal() {
    clearInterval(handle)
}

process.on('SIGINT', handleSignal)
process.on('SIGTERM', handleSignal)