function fibo(n) {
    return (n < 2) ? 1 : fibo(n - 2) + fibo(n - 1)
}
function fact(n) {
    return (n < 2) ? 1 : n * fact(n - 1)
}
exports.calculate = function (obj) {
    var res;
    if (typeof (obj.numb) != 'number') res = NaN;
    else {
        switch (obj.func) {
            case 'fibo': res = fibo(obj.numb); break;
            case 'fact': res = fact(obj.numb); break;
            default: res = NaN;
        }
    }
    return res;
}