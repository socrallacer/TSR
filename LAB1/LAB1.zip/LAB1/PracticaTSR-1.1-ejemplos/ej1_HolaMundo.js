

console.log ("hola mundo")

cnt = 0;

function imprime (msg) {

	console.log (cnt++ + ".- " + msg);
}

imprime ("hola mundo")
imprime ("adios")
